# Merak Bahçesi · Ortaokul, Lise ve Üniversite

Rize İl Millî Eğitim Müdürlüğü çalışması için Türkçe ve mobil uyumlu din kültürü platformu. Öğretmen takip sistemi ayrı `okultakipburakhoca` deposundadır.

## Sayfalar

- Ana sayfa: https://gencbeyinlernet.github.io/nazmihocaproje/
- Herkes için ortak ilk hikâye: https://gencbeyinlernet.github.io/nazmihocaproje/ortak-hikaye/
- Ana sayfadaki ikinci görselli hikâye: https://gencbeyinlernet.github.io/nazmihocaproje/igneden-kainata/
- Ortaokul (5–8): https://gencbeyinlernet.github.io/nazmihocaproje/ortaokul/
- Lise (9–12): https://gencbeyinlernet.github.io/nazmihocaproje/lise/
- Üniversite: https://gencbeyinlernet.github.io/nazmihocaproje/universite/
- Görselli hikâyeler: https://gencbeyinlernet.github.io/nazmihocaproje/sahne-atolyesi/
- Diğer sınıflar: `siniflar/6-sinif/` … `siniflar/12-sinif/`.
- İlk özgün metnin sekiz haftalık çalışması: `metin-atolyesi/`.

24 Ekim 2026 tarihli kullanıcı isteğiyle **4. sınıf aktif katalogdan, sınıf seçicisinden, soru formundan ve sahne atölyesinden kaldırıldı**. Önceki çalışmalar `arsiv/4-sinif/` altında korunur. Eski 4. sınıf ve ilkokul bağlantıları 5. sınıfa yönlenir; uygulama arşiv dosyalarını yüklemez.

## Hazır içerikler

**İkinci hikâye: “İğneden Kâinata: Bir Sorunun İzinde”.** Ana sayfada ortak ilk hikâyenin hemen ardından gelir. Kullanıcının ikinci metnini ele alan özgün konuşmalar, **4 bölüm × 7 sahne = 28 sahne** halinde hazırlanır. Atölye/iğne, tren, nar ağacı ve kâinat için dört yeni görsel; görev sırası için bir SVG şeması vardır. Aynı görsel, ilgili konuşmalarda farklı odak ve efektlerle kullanılır; 28 ayrı resim olduğu iddia edilmez.

Her repliğin konuşmacısı, görseli, odak noktası ve efekti birlikte değişir. Görsel yüklenmeden yeni konuşma gösterilmez; geciken eski bir istek sonraki seçimi değiştiremez. Geri/İleri, bölüm ve sahne seçimi, klavye okları, dokunmatik kaydırma ve isteğe bağlı otomatik okuma vardır. İğnede vurgu, trende hareket çizgileri, nar ağacında su/ışık, kâinatta yavaş yörünge efektleri kullanılır. Efektler kapatılabilir; hareket azaltma tercihinde kapalıdır. Düğmeler konuşma metnini kapatmaz.

Konuşmada adı geçen nesneler, resimle birlikte hareket eden konum işaretleriyle vurgulanır; kısa adları görsel altında okunur. Görselin köşesindeki büyütme düğmesi aynı sahnenin tam resmini ayrı bir pencerede açar ve otomatik ilerlemeyi durdurur. Escape, kapatma düğmesi veya dış alana dokunmayla kapanır; odak düğmeye döner. Yeniden ilerlemek kullanıcının seçimidir. Bölüm kartları ve sahne listesi, her bölüm için incelenen sahne sayısını ve yedi sahnesi de görülen bölümün yeşil durumunu gösterir. Bu sayaçlar ses dinleme, video veya sınav puanı sayılmaz.

Sekiz saniye, her sahnenin üretim hedefidir (toplam 224 saniye). Sessiz otomatik okuma, uzun repliklerde daha fazla süre verir. Sesler henüz eklenmedi; tarayıcı seslendirmesi kullanılmaz. İleride onaylı ses dosyası bağlandığında kayıt bitmeden sahne değiştirilmez. Pencere/menü açılması ve sekmenin gizlenmesi otomatik okumayı durdurur; elle tekrar başlatılır. Hata halinde otomatik ilerleme durur ve görsel için yeniden deneme gösterilir.

İkinci metnin tamamı **`assets/ikinci-hikaye-kaynak.txt` içinde aynen korunur** ve okunup indirilebilir. Konuşmalar, görsel/efekt planı ve öğretmen notları [IKINCI-HIKAYE.md](IKINCI-HIKAYE.md) içindedir; sayfadan seslendirme planı indirilebilir. Örneklerin sınırlarına ilişkin öğretmen notları öğrenci konuşmalarından ayrı açılır. İncelenen sahneler ve son sahne `merak-visual-story-v1` altında yerelde saklanır; 28 sahnenin hepsi açılmadan ve kullanıcı açıkça bitirmeden tamamlandı gösterilmez. Ortak ilk hikâye, sınıf ve sınav ilerlemeleri ayrı kalır.

**Ortak ilk hikâye: “Saraydan Dünyaya: Büyük Keşif”.** Ana sayfanın orta slayt alanında ilk sıradadır; ortaokul, lise, üniversite ve bütün sınıf sayfalarında ortak başlangıç bağlantısı bulunur. Elif, Deniz ve Derya Öğretmen ile sekiz bağlantılı durak, kullanıcının verdiği metindeki saray → amaç ve görev → elçi ve rehberlik → Dünya ve doğa → robot → sonuç akışını işler. Bu, kitapların konu sırasından ayrı bir ortak başlangıçtır.

Okuma hikâyesi, her durakta düşünme sorusu ve isteğe bağlı çalışma hazırdır. Üretim planında **8 durak × 7 sahne × 8 saniye = 56 sahne / 448 saniyelik hedef** vardır. Her sahnenin konuşmacısı, repliği ve görsel tarifi [ORTAK-HIKAYE.md](ORTAK-HIKAYE.md) içinde ve indirilebilir seslendirme planında yer alır. Ortak hikâyenin sahne görselleri, sesleri ve videosu henüz üretilmedi; kapak ayrı bir SVG çizimidir. Okuma sayfası bu dosyalar hazırmış gibi oynatmaz.

Kaynak metnin **tamamı `assets/source.txt` üzerinden aynen gösterilir ve indirilebilir**; özgün hikâye uyarlaması ondan ayrı sunulur. Okuma ilerlemesi `merak-common-story-v1` anahtarında tutulur. Bir sayfayı açmak veya İleri ile geçmek okunmuş saymaz; “Okudum” düğmesi açıkça işaretler. Sekiz durak işaretlenmeden tamamlanma gösterilmez. Bu durum mevcut sınıf, sınav, video, rozet veya sertifika kayıtlarını değiştirmez.

Aktif katalog 5–12. sınıflarda 35 ünite ve 163 konu planı içerir. Başlıklar ve sayfa referansları yüklenen kitapların sırasındadır. Kaynak dökümü: [KAYNAKLAR.md](KAYNAKLAR.md). 7. sınıf dosyası aktarım sınırını aştığından o sınıfın ayrı sayfasında konu sırası beklenir; tahminî başlık eklenmez.

5. sınıf “Allah İnancı” ünitesinin ilk üç konusu görselli hikâyelere bağlanır:

1. **Evrendeki Mükemmel Düzen** · “Gökyüzü Kulübünün İlk Buluşması” · s. 14.
2. **Allah’ın Varlığı ve Birliği** · “Birliğin Anlamını Ararken” · s. 20.
3. **Allah’ın Güzel İsimleri** · “İsimlerin Açtığı Pencere” · s. 29.

Her hikâye **7 sahne × 8 saniye = 56 saniye** olarak planlanır. Toplam 21 ayrı görsel, her görsele ait konuşmacı ve replik, ilerideki hareket tarifi, indirilebilir senaryo ve SRT taslağı bulunur. Zehra ve Ömer’in gözlem kulübü, üç konuyu sırayla birbirine bağlar. Diğer konular görselleri veya sesi hazırmış gibi gösterilmez.

**Ses dosyalarını kullanıcı çalışmanın sonunda yükleyecek.** Şu an aktif içeriklerde ses veya video dosyası yoktur; önizleme sessizdir. Eski ses denemeleri kullanılmaz. Her repliğin hedef karakter sesi ve dosya adı [SESLENDIRME-PLANI.md](SESLENDIRME-PLANI.md) ve `ses-planlari/karakter-sesleri.json` içinde hazırdır.

## Yaşa göre sade görünüm

Ana sayfanın ortasında ortak ilk hikâyeyle başlayan slayt gösterisi, altında üç eğitim düzeyi bulunur. Sınıf sayfalarının slaytları yalnızca seçili sınıf ve ünitenin hazır içeriklerini gösterir; ortak ilk hikâye bunların üzerinde ayrı bir bağlantıdır. Ortaokulda sınıf → belirgin “Hikâyeye başla” düğmesi → büyük görsel ve replik → Geri/İleri akışı vardır. Hazırlanmamış konular ve kaynak bilgileri kapalı ayrıntılardadır. Sınıf hikâyesinin tamamlanması, yedi görsel ziyaret edilip öğrenci “Bitirdim” dediğinde kaydedilir; video izlenmiş veya sınav geçilmiş sayılmaz. Mevcut okuma ilerlemesi ve tamamlanan kartların yeşil durumu korunur.

Geniş ekranda sınıflar soldaki sabit menüde Ortaokul ve Lise başlıkları altında listelenir; Üniversite ayrı bir kategoridir. Seçili sınıf belirgin görünür. Mobil ve tablette üstteki “Sınıflar” düğmesi aynı menüyü açar. Sınıf seçimi, kapatma düğmesi, dış alana dokunma veya Escape ile kapanır; klavye odağı menü içinde kalır ve kapanınca düğmeye döner. Hikâye sesi ya da öğretmen önizlemesi menü açılırken duraklatılır.

Sağ sütunun en üstünde “Soru sor”, altında hikâyeler, metin atölyesi, yerel test ve kullanım koşulları bağlantıları vardır. Soru formu ayrı bir pencerede açılır; mevcut özel takip kodu ve eğitimci akışı korunur. Mobilde soru düğmesi üstte kalır, diğer menüler isteğe bağlı açılır. Slaytlar 7 saniyede otomatik geçer; oklar, seçim noktaları, klavye okları ve dokunmatik yatay kaydırma ile elle seçilebilir. Elle seçim veya klavye odağı otomatik geçişi durdurur; düğmeyle yeniden başlatılır. Fare üzerindeyken, sekme gizliyken, onay beklenirken ve bir pencere/menü açıkken otomatik geçiş bekler. Hareket azaltma tercihi varsa otomatik geçiş kapalı başlar. Tek içerikte geçiş denetimleri gösterilmez.

Lisede daha olgun renkler, ünite/konu araması, kısa okuma ve düşünme soruları kullanılır. Üniversite alanında profesyonel okuma düzeniyle üç özgün tartışma planı ve indirilebilir çalışma notları vardır. **Üniversite kaynakları henüz eklenmemiştir; bu planlar kaynaklandırılmış üniversite dersleri olarak sunulmaz.** Notlar sayfada geçici tutulur; kullanıcı isterse metin dosyası olarak indirir.

Teknik senaryo, hareket tarifi, ses dosyası deneme ve indirme araçları öğrenci ekranında görünmez. Atölyede `?gorunum=ogretmen`, sınıf sayfasında aynı parametre öğretmen görünümünü açar. Bu bir görünüm seçimidir; yönetici girişi veya yetkilendirme değildir. Araçlar site kaynağını değiştirmez, sunucuya dosya yüklemez.

## Çalışma akışı

Öğrenci ortak ilk hikâyeden başlayabilir; ardından eğitim düzeyini ve sınıfını seçer. Sınıf sayfası hazır hikâyelerden birini belirgin bir başlangıç düğmesiyle önerir. Görselli içerik öğrenci oynatıcısında açılır; yalnızca görsel, konuşmacı/replik ve ilerleme düğmeleri görünür. Görseli olmayan hazır hikâyeler kısa bilgi → hikâye şeklinde ilerler. Gerçek video eklenene kadar öğrenciye boş bir video adımı gösterilmez. Sesler daha sonra bağlanır; kayıt bitmeden otomatik ilerlenmez.

Öğretmen görünümünde bütün kitap konu planları ve önceki ayrıntılı inceleme araçları korunur. Ortak soru/cevap alanı sağ üstteki “Soru sor” düğmesiyle açılır. Kullanım koşulları başlangıçta kısa özet ve açılabilir tam metinle gösterilir; mevcut onay zorunluluğu değişmez.

5. sınıf hikâyelerinin sahne görselleri ve ikinci hikâyenin dört anlatım görseli özgün yapay zekâ üretimidir. Açıklama ve hikâyeler, öğretmen/içerik sorumlusu incelemesi bekleyen özgün uyarlamalardır; kitap metni, ayet veya hadis alıntısı gibi sunulmaz. Kitapların tam PDF’leri depoya eklenmez. Kullanıcının ilk `assets/source.txt` ve ikinci `assets/ikinci-hikaye-kaynak.txt` metinleri değişmeden korunur. Gerçek kurum logosu `logo.jpg` dosyasıdır.

## Gizlilik ve soru alanı

Başlangıçta [KULLANIM-KOSULLARI.md](KULLANIM-KOSULLARI.md) için onay istenir. İzin mercii Rize İl Millî Eğitim Müdürlüğüdür. Onay tarayıcıda tutulur; kimlik doğrulanmış sunucu sözleşmesi veya teknik kopyalama koruması değildir. Kamuya açık GitHub dosyalarına doğrudan erişilebilir.

Soru/görüş, takip koduyla özel cevap ve yetkili eğitimci ekranları vardır. **Soru sunucusu henüz bağlı değildir; gerçek gönderme ve sorgu kapalıdır.** Kurulum: [backend/QUESTIONS-SETUP.md](backend/QUESTIONS-SETUP.md). Sunucu anahtarı veya şifre GitHub’a yazılmaz. Cihazdan seçilen deneme sesi yalnızca açık sayfada kalır; sunucuya yüklenmez ve yenilemede kaldırılır.

## Yerel test ve dosyalar

[Yerel test paketini indir](indir/merak-bahcesi-yerel-test.zip). ZIP’i çıkarıp Windows’ta `BASLAT-WINDOWS.bat`, Mac/Linux’ta `python3 BASLAT.py` çalıştır. Python 3 gerekir; paket kurulumu ve derleme gerekmez. Ayrıntılar: [YEREL-TEST.md](YEREL-TEST.md).

- `assets/catalog.js`: aktif 5–12 katalog, ünite ve konu sırası.
- `assets/productions.js`: üç 5. sınıf senaryosu, 21 sahne ve dört hedef ses profili.
- `assets/scenes/`: yeni sahne görselleri.
- `assets/portal.js`, `portal.css`, `audiences.css`: eğitim düzeyleri, yaşa uygun sınıf görünümü ve gezinme.
- `assets/navigation.js`, `navigation.css`: ortak sınıf menüsü ve mobil açılır panel.
- `assets/discovery.js`, `discovery.css`: sağ menü, soru penceresi ve otomatik/manuel slayt gösterisi.
- `assets/common-story-data.js`, `common-story.js`, `common-story.css`: sekiz duraklı ortak hikâye, 56 sahnenin planı ve okuma ilerlemesi.
- `assets/common-palace.svg`: ortak hikâyenin kapak çizimi.
- `assets/visual-story-data.js`, `visual-story.js`, `visual-story.css`: ikinci hikâyenin görsel/replik/efekt oynatıcısı ve ayrı ilerlemesi.
- `assets/visual-story/`: dört üretilmiş anlatım görseli ve görev sırası şeması.
- `assets/university.js`: kaynak seçimi bekleyen üç özgün üniversite tartışma planı.
- `assets/portal-authoring.js`: öğretmenin tüm konu planlarını incelediği görünüm.
- `assets/studio.js`: sade öğrenci hikâye oynatıcısı.
- `assets/studio-authoring.js`, `studio.css`: öğretmen için görsel/replik/ses ve üretim araçları.
- `assets/privacy.js`, `privacy.css`: ortak onay ekranı.
- `assets/questions.js`, `question-service.js`, `backend/`: özel soru/cevap altyapısı.
- `scripts/package-local.py`: arşivi dışarıda tutarak güncel yerel paketi oluşturur.
- `tests/`: tarayıcı testleri; uygulamayı çalıştırmak için test araçları gerekmez.
