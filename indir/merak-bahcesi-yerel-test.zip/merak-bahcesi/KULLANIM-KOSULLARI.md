# Paylaşım ve gizlilik

Merak Bahçesi · Rize İl Millî Eğitim Müdürlüğü çalışması. Güncelleme: 24 Ekim 2026.

## Herkese açık ve paylaşılabilir

Platform herkes tarafından kullanıcı adı, şifre veya üyelik olmadan kullanılabilir. İçeriğe girmek için sözleşme kabulü veya onay gerekmez.

Platformun özgün hikâye, senaryo, görsel ve etkinliklerini sınıfta sunabilir, kopyalayabilir, bağlantılarıyla veya materyal olarak paylaşabilir ve yeniden yayınlayabilirsiniz. Ayrıca izin almanız gerekmez. Kaynak olarak Merak Bahçesi ve Rize İl Millî Eğitim Müdürlüğünü belirtebilirsiniz.

Ders kitaplarının konu sırası ve sayfa referansları kaynak gösterilir. Kitapların tam PDF’leri bu sitede yayınlanmaz. Üçüncü taraf kitapların ve dış hizmetlerin kendi koşulları geçerlidir. Hikâyeler özgün uyarlamalardır; kullanıcının verdiği iki kaynak metnin tamamı ayrıca değiştirilmeden korunur.

Geçici sentetik seslerin model/veri kümesi lisansları ayrıca geçerlidir. DFKI örnek kayıtları kaynak gösterilerek ticari olmayan amaçlarla, aynı CC BY-NC-SA 4.0 lisansıyla paylaşılır. [Ses kaynak ve lisans bilgisi](assets/audio/CREDITS.md). Gerçek kayıtlar geldikçe bu örnekler değiştirilebilir.

## Bu cihazdaki bilgiler

Dinlenen duraklar, tamamlanan sahneler, son açılan içerik ve önceki öğrenme etkinliğinin ilerlemesi tarayıcıda saklanır. Örnek dersteki oyun ilerlemesi, son sınav puanı ve en iyi puan da yalnız bu tarayıcıda tutulur. Önceki sertifikaya yazılmış ad da bu cihazda bulunabilir. Kayıtlar diğer cihazlara otomatik taşınmaz. Öğretmenin düzenlediği ders planı sayfada geçici tutulur; indirildiğinde kendi cihazında dosya olur. Hesap veya sunucu kaydı yapılmaz.

Paylaşım ve gizlilik penceresindeki “Bu cihazdaki öğrenme kayıtlarını sil” düğmesi yerel ilerlemeyi, oyun/sınav kayıtlarını ve varsa soru takip kodunu siler. Site üyelik veya yeniden onay istemeden açılmaya devam eder. Bu işlem gelecekteki soru sunucusunun kayıtlarını silmez.

## Soru ve cevap alanı

Paylaşılabilir eğitim içerikleri ile kişisel sorular birbirinden ayrıdır. Soruya ad, okul, telefon, e-posta veya başkalarının özel bilgileri yazılmamalıdır. Soru hizmeti açıldığında yanıt yalnızca özel takip koduyla görülebilir; sorular herkese yayınlanmaz. Hizmet şu anda bağlı değildir; gerçek gönderim ve sorgu kapalıdır. Form metni otomatik saklanmaz. Özel soru yönetimi için sunucu yetkilendirmesi korunur; herkese açık öğrenme sayfalarında giriş ekranı bulunmaz.

## Dış hizmetler

Google Drive gibi bağlantılar yalnızca kullanıcı tıkladığında açılır. Bu sürümde reklam, analiz takipçisi veya dış yazı tipi isteği yoktur. Paylaşım düğmesi cihazın paylaşım menüsünü açar veya bağlantıyı kopyalar; kullanıcı paylaşacağı yeri kendisi seçer.
